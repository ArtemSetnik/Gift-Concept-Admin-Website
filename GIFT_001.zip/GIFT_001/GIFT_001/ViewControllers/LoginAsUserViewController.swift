//
//  ViewController.swift
//  GIFT_001
//
//  Created by Lexy on 6/28/19.
//  Copyright © 2019 Lexy. All rights reserved.
//

import UIKit

class LoginAsUserViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setCustomTitle()
        setBackbarImage()
    }
    
    func setBackbarImage()
    {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }

    func setCustomTitle()
    {
        let label1 = UILabel()
        label1.text = "Fantasnic"
        label1.font = UIFont(name: "Menlo", size: 30)
        label1.textColor = .white
        label1.sizeToFit()
        
        let label2 = UILabel()
        label2.text = "Journey"
        label2.font = UIFont(name: "Redressed", size: 30)
        label2.sizeToFit()
        
        let stackView = UIStackView(arrangedSubviews: [label1, label2])
        stackView.axis = .horizontal
        stackView.frame.size.width = label1.frame.width + label2.frame.height
        stackView.frame.size.height = label1.frame.height + label2.frame.height
    }

}

