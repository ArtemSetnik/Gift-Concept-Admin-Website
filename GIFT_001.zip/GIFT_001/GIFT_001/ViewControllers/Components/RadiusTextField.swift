//
//  RadiusTextField.swift
//  GIFT_001
//
//  Created by Lexy on 6/30/19.
//  Copyright © 2019 Lexy. All rights reserved.
//

import UIKit

class RadiusTextField: UITextField {
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUI()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initUI()
    }
    func initUI() {
        tintColor = .white
        textColor = .darkGray
        backgroundColor = UIColor(white: 0.0, alpha: 0.2)
        font = UIFont(name: "Avenir", size: 18)
        autocorrectionType = .no
        layer.cornerRadius = frame.size.height / 2
        clipsToBounds = true
        
        let placeholder = self.placeholder != nil ? self.placeholder! : ""
        let placeholderFont = UIFont(name: "Avenir", size: 18)
        attributedPlaceholder = NSAttributedString(
            string: placeholder,
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray, NSAttributedString.Key.font: placeholderFont]
        )
        
        let indentView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        leftView = indentView
        leftViewMode = .always
    }
}
