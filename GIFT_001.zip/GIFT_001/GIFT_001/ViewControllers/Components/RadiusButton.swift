//
//  RadiusButton.swift
//  GIFT_001
//
//  Created by Lexy on 6/30/19.
//  Copyright © 2019 Lexy. All rights reserved.
//

import UIKit

class RadiusButton: UIButton {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    override init(frame: CGRect) {
        super.init(frame: frame)
        initUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initUI()
    }
    
    func initUI() {
        layer.cornerRadius = frame.size.height / 2
    }
    
}
