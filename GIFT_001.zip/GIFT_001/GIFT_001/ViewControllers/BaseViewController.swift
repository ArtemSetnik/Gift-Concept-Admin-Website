//
//  BaseViewController.swift
//  GIFT_001
//
//  Created by Lexy on 6/30/19.
//  Copyright © 2019 Lexy. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    let BackgroundImageView = UIImageView()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func setBackground() {
        view.addSubview(BackgroundImageView)
        BackgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        BackgroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        BackgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        BackgroundImageView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        BackgroundImageView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        
        BackgroundImageView.image = UIImage(named: "")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
